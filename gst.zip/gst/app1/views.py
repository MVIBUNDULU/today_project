from django.shortcuts import render
from app1.models import Produit,Stock,Vente
# Create your views here.

def home(request):
    produits=Produit.objects.all()
    toto=Vente.objects.all()
    data={'produits':produits,'vente':toto}
    if request.method=="POST":
        recupere=request.POST
        produit=Produit.objects.get(id=int(recupere.get('designation')))
        #produit=Produit.objects.get(designation=recupere.get('designation'))
        if produit.diminuer_qte(int(recupere.get('qte_achete'))):
            isinstance=Vente.objects.create(
                designation_produit=recupere.get('designation'),
                qte_achete=int(recupere.get('qte_achete'))
            )
            print("les données ont été save")
    print("L'insertion n'a pas eu lieu")
    
    return render(request, 'index.html',data)