from django.db import models
import uuid
# Create your models here.
class Produit(models.Model):
    designation=models.CharField(max_length=50, unique=True)
    prix=models.IntegerField()
    date_recep=models.DateField()
    secrete_key=models.UUIDField(default=uuid.uuid4)

    def __str__(self):

        return f'{self.designation}'

    def diminuer_qte(self,qte):
        if(self.qte_produit.qte_stock >= qte):
            self.qte_produit.qte_stock-=qte
            self.qte_produit.save
            True
        False

class Stock(models.Model):
    produit=models.OneToOneField(Produit, on_delete=models.CASCADE, related_name="qte_produit")
    qte_stock=models.IntegerField()

    def __str__(self):

        return f"{self.produit} / {self.qte_stock}"
    

class Vente(models.Model):
    designation_produit=models.ForeignKey(Produit,on_delete=models.CASCADE, related_name="qt_produit")
    qte_achete=models.IntegerField()
    pu=models.IntegerField(editable=False)
    pht=models.IntegerField(default=0,editable=False)
    secrete_key=models.UUIDField(default=uuid.uuid4)

    def __str__(self):

        return f"Produit: {self.designation_produit}/ {self.qte_achete}/ {self.pu}/ {self.pht}"
    
    def save(self, *args, **kwargs):
        self.pu=self.designation_produit.prix
        self.pht=int(self.pu*self.qte_achete)
        super().save(*args, **kwargs)
